﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Console;

namespace WindowsFormsApp2
{
    public partial class Form1 : Form
    {

        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            const int rate = 15;
            string emp;
            double weekNum, monHour, tuHour, wedHour, thurHour, friHour, satHour, sunHour, monHour2, tuHour2, wedHour2, thurHour2, friHour2, satHour2, sunHour2;

            emp = Convert.ToString(textBoxEmp.Text);

            //calculate totals... I think there is a more  efficient way of calculating it  but this isnt it :(

            weekNum = int.Parse(textboxReport.Text);
            //Monday Totals
            MonTot.Text = sumWork(monHour = int.Parse(textBoxMon.Text), monHour2 = int.Parse(textBoxMon2.Text));

            //tues total
            TuesTot.Text = sumWork(tuHour = int.Parse(textBoxTue2.Text), tuHour2 = int.Parse(textBoxTue2.Text));
            //wed totals
            WedTot.Text = sumWork(wedHour = int.Parse(textBoxWed.Text), wedHour2 = int.Parse(textBoxWed2.Text));
            //Thursday
            ThursTot.Text = sumWork(thurHour = int.Parse(textBoxThur.Text), thurHour2 = int.Parse(textBoxThu2.Text));
            //Friday
            FriTot.Text = sumWork(friHour = int.Parse(textBoxFrid.Text), friHour2 = int.Parse(textBoxFrid2.Text));
            //Sat
            SatTot.Text = sumWork(satHour = int.Parse(textBoxSat.Text), satHour2 = int.Parse(textBoxSat2.Text));
            //Sun
            SunTot.Text = sumWork(sunHour = int.Parse(textBoxSun.Text), sunHour2 = int.Parse(textBoxSun2.Text));


            /* tuHour = Convert.ToDouble(textBoxTues.Text);
             wedHour = Convert.ToDouble(textBoxWed.Text);
             thurHour = Convert.ToDouble(textBoxThu2.Text);
             */

            label19.Text = String.Format("Payroll information for {0} for the week ending {1} :", emp, weekNum);

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void label13_Click(object sender, EventArgs e)
        {

        }

        private void textBoxName_TextChanged(object sender, EventArgs e)
        {
            

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void Total3_TextChanged(object sender, EventArgs e)
        {

        }

        private void label19_Click(object sender, EventArgs e)
        {

        }

        private void textboxReport_KeyDown(object sender, KeyEventArgs e)
        {

        }

        private void textboxReport_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) || textboxReport.TextLength > 1)
            {
                e.Handled = true;

                //this creates a messagebox
                
            }

        }

        private void textBoxMon_Validated(object sender, EventArgs e)
        {
           
        }

        private void textboxReport_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBoxMon_KeyPress(object sender, KeyPressEventArgs e)
        {
           

            
            
        }

        private void textBoxProj1_KeyDown(object sender, KeyEventArgs e)
        {
            panel1.Visible = true;
        }

        private void textboxReport_Validated(object sender, EventArgs e)
        {
            if (textboxReport.Text != "")
            try
            {
                int tbval;
                tbval = Convert.ToInt32(textboxReport.Text);
                    if(tbval > 52)
                    {
                        textboxReport.Text = "";
                    }
            }
                catch(Exception )
                {
                    label20.Visible = true;
                }
            label20.Visible = false;
        }

        private void textBoxSun2_KeyPress(object sender, KeyPressEventArgs e)
        {
            button1.Enabled = true;
        }
        private String sumWork(double hours, double hour2)
        {
            double Tots = 0;
                Tots += hours + hour2;
            return Tots.ToString();
        }

        private void checkBox1_KeyPress(object sender, KeyPressEventArgs e)
        {

            if (checkBox1.Checked == true)
            {
                //set to null since it's vacation holiday etc
               textBoxMon.Text = "";
                textBoxMon2.Text = "";
            }

        }
    }
}
