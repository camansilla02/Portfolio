﻿namespace WindowsFormsApp2
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button1 = new System.Windows.Forms.Button();
            this.textBoxEmp = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.textBoxSup = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.textboxReport = new System.Windows.Forms.TextBox();
            this.textBoxClient1 = new System.Windows.Forms.TextBox();
            this.textBoxContr1 = new System.Windows.Forms.TextBox();
            this.textBoxClient2 = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.checkBox2 = new System.Windows.Forms.CheckBox();
            this.checkBox3 = new System.Windows.Forms.CheckBox();
            this.checkBox4 = new System.Windows.Forms.CheckBox();
            this.checkBox5 = new System.Windows.Forms.CheckBox();
            this.checkBox6 = new System.Windows.Forms.CheckBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.TextboxTot3 = new System.Windows.Forms.TextBox();
            this.textBoxFrid2 = new System.Windows.Forms.TextBox();
            this.textBoxSun2 = new System.Windows.Forms.TextBox();
            this.textBoxTot2 = new System.Windows.Forms.TextBox();
            this.MonTot = new System.Windows.Forms.TextBox();
            this.FriTot = new System.Windows.Forms.TextBox();
            this.SatTot = new System.Windows.Forms.TextBox();
            this.SunTot = new System.Windows.Forms.TextBox();
            this.TuesTot = new System.Windows.Forms.TextBox();
            this.WedTot = new System.Windows.Forms.TextBox();
            this.ThursTot = new System.Windows.Forms.TextBox();
            this.textBoxThu2 = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.textBoxSat2 = new System.Windows.Forms.TextBox();
            this.textBoxWed2 = new System.Windows.Forms.TextBox();
            this.textBoxTue2 = new System.Windows.Forms.TextBox();
            this.textBoxMon2 = new System.Windows.Forms.TextBox();
            this.textBoxTot1 = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.textBoxSun = new System.Windows.Forms.TextBox();
            this.textBoxFrid = new System.Windows.Forms.TextBox();
            this.textBoxSat = new System.Windows.Forms.TextBox();
            this.textBoxThur = new System.Windows.Forms.TextBox();
            this.textBoxWed = new System.Windows.Forms.TextBox();
            this.textBoxTues = new System.Windows.Forms.TextBox();
            this.textBoxMon = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.checkBox7 = new System.Windows.Forms.CheckBox();
            this.label17 = new System.Windows.Forms.Label();
            this.textBoxContr2 = new System.Windows.Forms.TextBox();
            this.textBoxProj1 = new System.Windows.Forms.TextBox();
            this.textBoxProj2 = new System.Windows.Forms.TextBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.labelResult = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.SeaGreen;
            this.button1.Enabled = false;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button1.Location = new System.Drawing.Point(25, 479);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(109, 37);
            this.button1.TabIndex = 0;
            this.button1.Text = "Submit";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // textBoxEmp
            // 
            this.textBoxEmp.Location = new System.Drawing.Point(135, 69);
            this.textBoxEmp.Name = "textBoxEmp";
            this.textBoxEmp.Size = new System.Drawing.Size(100, 20);
            this.textBoxEmp.TabIndex = 1;
            this.textBoxEmp.TextChanged += new System.EventHandler(this.textBoxName_TextChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial Black", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(22, 71);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(107, 15);
            this.label1.TabIndex = 2;
            this.label1.Text = "Employee Name:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Arial Black", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(19, 106);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(114, 15);
            this.label2.TabIndex = 3;
            this.label2.Text = "Supervisor Name:";
            // 
            // textBoxSup
            // 
            this.textBoxSup.Location = new System.Drawing.Point(135, 106);
            this.textBoxSup.Name = "textBoxSup";
            this.textBoxSup.Size = new System.Drawing.Size(100, 20);
            this.textBoxSup.TabIndex = 2;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Arial Black", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(19, 143);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(111, 15);
            this.label3.TabIndex = 6;
            this.label3.Text = "Reporting period:";
            // 
            // textboxReport
            // 
            this.textboxReport.Location = new System.Drawing.Point(136, 141);
            this.textboxReport.MaxLength = 2;
            this.textboxReport.Name = "textboxReport";
            this.textboxReport.Size = new System.Drawing.Size(100, 20);
            this.textboxReport.TabIndex = 3;
            this.textboxReport.Validated += new System.EventHandler(this.textboxReport_Validated);
            // 
            // textBoxClient1
            // 
            this.textBoxClient1.Location = new System.Drawing.Point(6, 29);
            this.textBoxClient1.Name = "textBoxClient1";
            this.textBoxClient1.Size = new System.Drawing.Size(93, 20);
            this.textBoxClient1.TabIndex = 4;
            // 
            // textBoxContr1
            // 
            this.textBoxContr1.Location = new System.Drawing.Point(113, 29);
            this.textBoxContr1.Name = "textBoxContr1";
            this.textBoxContr1.Size = new System.Drawing.Size(90, 20);
            this.textBoxContr1.TabIndex = 5;
            // 
            // textBoxClient2
            // 
            this.textBoxClient2.Location = new System.Drawing.Point(6, 66);
            this.textBoxClient2.Name = "textBoxClient2";
            this.textBoxClient2.Size = new System.Drawing.Size(93, 20);
            this.textBoxClient2.TabIndex = 15;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Arial Black", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(3, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(81, 15);
            this.label4.TabIndex = 11;
            this.label4.Text = "Client Name";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Arial Black", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(114, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(99, 15);
            this.label5.TabIndex = 12;
            this.label5.Text = "Client Contract";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Arial Black", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(235, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(65, 15);
            this.label6.TabIndex = 13;
            this.label6.Text = "Project(s)";
            this.label6.Click += new System.EventHandler(this.label6_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Arial Black", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(16, 295);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(37, 15);
            this.label7.TabIndex = 15;
            this.label7.Text = "Total";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.label8.Location = new System.Drawing.Point(18, 24);
            this.label8.Name = "label8";
            this.label8.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.label8.Size = new System.Drawing.Size(28, 13);
            this.label8.TabIndex = 16;
            this.label8.Text = "Mon";
            this.label8.UseMnemonic = false;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)), true);
            this.label9.Location = new System.Drawing.Point(76, 24);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(31, 13);
            this.label9.TabIndex = 17;
            this.label9.Text = "Tues";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(130, 24);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(30, 13);
            this.label10.TabIndex = 18;
            this.label10.Text = "Wed";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(187, 24);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(34, 13);
            this.label11.TabIndex = 19;
            this.label11.Text = "Thurs";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(234, 26);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(35, 13);
            this.label12.TabIndex = 20;
            this.label12.Text = "Friday";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(282, 26);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(49, 13);
            this.label13.TabIndex = 21;
            this.label13.Text = "Saturday";
            this.label13.Click += new System.EventHandler(this.label13_Click);
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(346, 26);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(43, 13);
            this.label14.TabIndex = 22;
            this.label14.Text = "Sunday";
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.Location = new System.Drawing.Point(376, 326);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(44, 17);
            this.checkBox1.TabIndex = 23;
            this.checkBox1.Text = "cb1";
            this.checkBox1.UseVisualStyleBackColor = true;
            this.checkBox1.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.checkBox1_KeyPress);
            // 
            // checkBox2
            // 
            this.checkBox2.AutoSize = true;
            this.checkBox2.Location = new System.Drawing.Point(434, 326);
            this.checkBox2.Name = "checkBox2";
            this.checkBox2.Size = new System.Drawing.Size(44, 17);
            this.checkBox2.TabIndex = 24;
            this.checkBox2.Text = "cb2";
            this.checkBox2.UseVisualStyleBackColor = true;
            // 
            // checkBox3
            // 
            this.checkBox3.AutoSize = true;
            this.checkBox3.Location = new System.Drawing.Point(488, 326);
            this.checkBox3.Name = "checkBox3";
            this.checkBox3.Size = new System.Drawing.Size(44, 17);
            this.checkBox3.TabIndex = 25;
            this.checkBox3.Text = "cb3";
            this.checkBox3.UseVisualStyleBackColor = true;
            // 
            // checkBox4
            // 
            this.checkBox4.AutoSize = true;
            this.checkBox4.Location = new System.Drawing.Point(545, 326);
            this.checkBox4.Name = "checkBox4";
            this.checkBox4.Size = new System.Drawing.Size(44, 17);
            this.checkBox4.TabIndex = 26;
            this.checkBox4.Text = "cb4";
            this.checkBox4.UseVisualStyleBackColor = true;
            // 
            // checkBox5
            // 
            this.checkBox5.AutoSize = true;
            this.checkBox5.Location = new System.Drawing.Point(595, 326);
            this.checkBox5.Name = "checkBox5";
            this.checkBox5.Size = new System.Drawing.Size(44, 17);
            this.checkBox5.TabIndex = 27;
            this.checkBox5.Text = "cb5";
            this.checkBox5.UseVisualStyleBackColor = true;
            // 
            // checkBox6
            // 
            this.checkBox6.AutoSize = true;
            this.checkBox6.Location = new System.Drawing.Point(643, 326);
            this.checkBox6.Name = "checkBox6";
            this.checkBox6.Size = new System.Drawing.Size(44, 17);
            this.checkBox6.TabIndex = 28;
            this.checkBox6.Text = "cb6";
            this.checkBox6.UseVisualStyleBackColor = true;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.LightSteelBlue;
            this.panel1.Controls.Add(this.TextboxTot3);
            this.panel1.Controls.Add(this.textBoxFrid2);
            this.panel1.Controls.Add(this.textBoxSun2);
            this.panel1.Controls.Add(this.textBoxTot2);
            this.panel1.Controls.Add(this.MonTot);
            this.panel1.Controls.Add(this.FriTot);
            this.panel1.Controls.Add(this.SatTot);
            this.panel1.Controls.Add(this.SunTot);
            this.panel1.Controls.Add(this.TuesTot);
            this.panel1.Controls.Add(this.WedTot);
            this.panel1.Controls.Add(this.ThursTot);
            this.panel1.Controls.Add(this.textBoxThu2);
            this.panel1.Controls.Add(this.label16);
            this.panel1.Controls.Add(this.textBoxSat2);
            this.panel1.Controls.Add(this.textBoxWed2);
            this.panel1.Controls.Add(this.textBoxTue2);
            this.panel1.Controls.Add(this.textBoxMon2);
            this.panel1.Controls.Add(this.textBoxTot1);
            this.panel1.Controls.Add(this.label18);
            this.panel1.Controls.Add(this.textBoxSun);
            this.panel1.Controls.Add(this.textBoxFrid);
            this.panel1.Controls.Add(this.textBoxSat);
            this.panel1.Controls.Add(this.textBoxThur);
            this.panel1.Controls.Add(this.textBoxWed);
            this.panel1.Controls.Add(this.textBoxTues);
            this.panel1.Controls.Add(this.textBoxMon);
            this.panel1.Controls.Add(this.label8);
            this.panel1.Controls.Add(this.label9);
            this.panel1.Controls.Add(this.label10);
            this.panel1.Controls.Add(this.label11);
            this.panel1.Controls.Add(this.label12);
            this.panel1.Controls.Add(this.label13);
            this.panel1.Controls.Add(this.label14);
            this.panel1.Location = new System.Drawing.Point(358, 153);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(476, 167);
            this.panel1.TabIndex = 29;
            this.panel1.Visible = false;
            // 
            // TextboxTot3
            // 
            this.TextboxTot3.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.TextboxTot3.Location = new System.Drawing.Point(406, 137);
            this.TextboxTot3.Name = "TextboxTot3";
            this.TextboxTot3.ReadOnly = true;
            this.TextboxTot3.Size = new System.Drawing.Size(39, 20);
            this.TextboxTot3.TabIndex = 55;
            this.TextboxTot3.TabStop = false;
            // 
            // textBoxFrid2
            // 
            this.textBoxFrid2.Location = new System.Drawing.Point(241, 90);
            this.textBoxFrid2.MaxLength = 2;
            this.textBoxFrid2.Name = "textBoxFrid2";
            this.textBoxFrid2.Size = new System.Drawing.Size(37, 20);
            this.textBoxFrid2.TabIndex = 22;
            // 
            // textBoxSun2
            // 
            this.textBoxSun2.Location = new System.Drawing.Point(345, 90);
            this.textBoxSun2.MaxLength = 2;
            this.textBoxSun2.Name = "textBoxSun2";
            this.textBoxSun2.Size = new System.Drawing.Size(44, 20);
            this.textBoxSun2.TabIndex = 24;
            this.textBoxSun2.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBoxSun2_KeyPress);
            // 
            // textBoxTot2
            // 
            this.textBoxTot2.Location = new System.Drawing.Point(404, 90);
            this.textBoxTot2.Name = "textBoxTot2";
            this.textBoxTot2.ReadOnly = true;
            this.textBoxTot2.Size = new System.Drawing.Size(41, 20);
            this.textBoxTot2.TabIndex = 53;
            this.textBoxTot2.TabStop = false;
            // 
            // MonTot
            // 
            this.MonTot.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.MonTot.Location = new System.Drawing.Point(17, 137);
            this.MonTot.Name = "MonTot";
            this.MonTot.ReadOnly = true;
            this.MonTot.Size = new System.Drawing.Size(39, 20);
            this.MonTot.TabIndex = 52;
            this.MonTot.TabStop = false;
            // 
            // FriTot
            // 
            this.FriTot.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.FriTot.Location = new System.Drawing.Point(241, 137);
            this.FriTot.Name = "FriTot";
            this.FriTot.ReadOnly = true;
            this.FriTot.Size = new System.Drawing.Size(37, 20);
            this.FriTot.TabIndex = 51;
            this.FriTot.TabStop = false;
            // 
            // SatTot
            // 
            this.SatTot.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.SatTot.Location = new System.Drawing.Point(287, 137);
            this.SatTot.Name = "SatTot";
            this.SatTot.ReadOnly = true;
            this.SatTot.Size = new System.Drawing.Size(44, 20);
            this.SatTot.TabIndex = 50;
            this.SatTot.TabStop = false;
            // 
            // SunTot
            // 
            this.SunTot.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.SunTot.Location = new System.Drawing.Point(349, 137);
            this.SunTot.Name = "SunTot";
            this.SunTot.ReadOnly = true;
            this.SunTot.Size = new System.Drawing.Size(40, 20);
            this.SunTot.TabIndex = 49;
            this.SunTot.TabStop = false;
            // 
            // TuesTot
            // 
            this.TuesTot.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.TuesTot.Location = new System.Drawing.Point(79, 137);
            this.TuesTot.Name = "TuesTot";
            this.TuesTot.ReadOnly = true;
            this.TuesTot.Size = new System.Drawing.Size(41, 20);
            this.TuesTot.TabIndex = 48;
            this.TuesTot.TabStop = false;
            // 
            // WedTot
            // 
            this.WedTot.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.WedTot.Location = new System.Drawing.Point(133, 137);
            this.WedTot.Name = "WedTot";
            this.WedTot.ReadOnly = true;
            this.WedTot.Size = new System.Drawing.Size(38, 20);
            this.WedTot.TabIndex = 47;
            this.WedTot.TabStop = false;
            this.WedTot.TextChanged += new System.EventHandler(this.Total3_TextChanged);
            // 
            // ThursTot
            // 
            this.ThursTot.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.ThursTot.Location = new System.Drawing.Point(187, 137);
            this.ThursTot.Name = "ThursTot";
            this.ThursTot.ReadOnly = true;
            this.ThursTot.Size = new System.Drawing.Size(41, 20);
            this.ThursTot.TabIndex = 46;
            this.ThursTot.TabStop = false;
            // 
            // textBoxThu2
            // 
            this.textBoxThu2.Location = new System.Drawing.Point(187, 90);
            this.textBoxThu2.MaxLength = 2;
            this.textBoxThu2.Name = "textBoxThu2";
            this.textBoxThu2.Size = new System.Drawing.Size(41, 20);
            this.textBoxThu2.TabIndex = 21;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(184, 5);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(88, 13);
            this.label16.TabIndex = 38;
            this.label16.Text = "Hours Worked";
            // 
            // textBoxSat2
            // 
            this.textBoxSat2.Location = new System.Drawing.Point(285, 90);
            this.textBoxSat2.MaxLength = 2;
            this.textBoxSat2.Name = "textBoxSat2";
            this.textBoxSat2.Size = new System.Drawing.Size(46, 20);
            this.textBoxSat2.TabIndex = 23;
            // 
            // textBoxWed2
            // 
            this.textBoxWed2.Location = new System.Drawing.Point(130, 90);
            this.textBoxWed2.MaxLength = 2;
            this.textBoxWed2.Name = "textBoxWed2";
            this.textBoxWed2.Size = new System.Drawing.Size(41, 20);
            this.textBoxWed2.TabIndex = 20;
            // 
            // textBoxTue2
            // 
            this.textBoxTue2.Location = new System.Drawing.Point(79, 90);
            this.textBoxTue2.MaxLength = 2;
            this.textBoxTue2.Name = "textBoxTue2";
            this.textBoxTue2.Size = new System.Drawing.Size(41, 20);
            this.textBoxTue2.TabIndex = 19;
            // 
            // textBoxMon2
            // 
            this.textBoxMon2.Location = new System.Drawing.Point(18, 90);
            this.textBoxMon2.MaxLength = 2;
            this.textBoxMon2.Name = "textBoxMon2";
            this.textBoxMon2.Size = new System.Drawing.Size(39, 20);
            this.textBoxMon2.TabIndex = 18;
            // 
            // textBoxTot1
            // 
            this.textBoxTot1.Location = new System.Drawing.Point(404, 53);
            this.textBoxTot1.Name = "textBoxTot1";
            this.textBoxTot1.Size = new System.Drawing.Size(41, 20);
            this.textBoxTot1.TabIndex = 14;
            this.textBoxTot1.TabStop = false;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(403, 26);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(42, 13);
            this.label18.TabIndex = 39;
            this.label18.Text = "Totals";
            // 
            // textBoxSun
            // 
            this.textBoxSun.Location = new System.Drawing.Point(345, 53);
            this.textBoxSun.MaxLength = 2;
            this.textBoxSun.Name = "textBoxSun";
            this.textBoxSun.Size = new System.Drawing.Size(41, 20);
            this.textBoxSun.TabIndex = 13;
            // 
            // textBoxFrid
            // 
            this.textBoxFrid.Location = new System.Drawing.Point(237, 53);
            this.textBoxFrid.MaxLength = 2;
            this.textBoxFrid.Name = "textBoxFrid";
            this.textBoxFrid.Size = new System.Drawing.Size(41, 20);
            this.textBoxFrid.TabIndex = 11;
            // 
            // textBoxSat
            // 
            this.textBoxSat.Location = new System.Drawing.Point(285, 53);
            this.textBoxSat.MaxLength = 2;
            this.textBoxSat.Name = "textBoxSat";
            this.textBoxSat.Size = new System.Drawing.Size(46, 20);
            this.textBoxSat.TabIndex = 12;
            // 
            // textBoxThur
            // 
            this.textBoxThur.Location = new System.Drawing.Point(187, 53);
            this.textBoxThur.MaxLength = 2;
            this.textBoxThur.Name = "textBoxThur";
            this.textBoxThur.Size = new System.Drawing.Size(41, 20);
            this.textBoxThur.TabIndex = 10;
            // 
            // textBoxWed
            // 
            this.textBoxWed.Location = new System.Drawing.Point(133, 53);
            this.textBoxWed.MaxLength = 2;
            this.textBoxWed.Name = "textBoxWed";
            this.textBoxWed.Size = new System.Drawing.Size(41, 20);
            this.textBoxWed.TabIndex = 9;
            // 
            // textBoxTues
            // 
            this.textBoxTues.Location = new System.Drawing.Point(79, 53);
            this.textBoxTues.MaxLength = 2;
            this.textBoxTues.Name = "textBoxTues";
            this.textBoxTues.Size = new System.Drawing.Size(41, 20);
            this.textBoxTues.TabIndex = 8;
            // 
            // textBoxMon
            // 
            this.textBoxMon.Location = new System.Drawing.Point(17, 53);
            this.textBoxMon.MaxLength = 2;
            this.textBoxMon.Name = "textBoxMon";
            this.textBoxMon.Size = new System.Drawing.Size(39, 20);
            this.textBoxMon.TabIndex = 7;
            this.textBoxMon.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBoxMon_KeyPress);
            this.textBoxMon.Validated += new System.EventHandler(this.textBoxMon_Validated);
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(16, 330);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(165, 13);
            this.label15.TabIndex = 37;
            this.label15.Text = "Weekend/Holiday/Vacation";
            // 
            // checkBox7
            // 
            this.checkBox7.AutoSize = true;
            this.checkBox7.Location = new System.Drawing.Point(700, 326);
            this.checkBox7.Name = "checkBox7";
            this.checkBox7.Size = new System.Drawing.Size(44, 17);
            this.checkBox7.TabIndex = 36;
            this.checkBox7.Tag = "Enter a number";
            this.checkBox7.Text = "cb7";
            this.checkBox7.UseVisualStyleBackColor = true;
            // 
            // label17
            // 
            this.label17.Font = new System.Drawing.Font("Microsoft YaHei", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Pixel, ((byte)(0)));
            this.label17.ForeColor = System.Drawing.Color.Teal;
            this.label17.Location = new System.Drawing.Point(269, 18);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(356, 31);
            this.label17.TabIndex = 30;
            this.label17.Text = "Employee Time Sheet";
            // 
            // textBoxContr2
            // 
            this.textBoxContr2.Location = new System.Drawing.Point(113, 66);
            this.textBoxContr2.Name = "textBoxContr2";
            this.textBoxContr2.Size = new System.Drawing.Size(93, 20);
            this.textBoxContr2.TabIndex = 16;
            // 
            // textBoxProj1
            // 
            this.textBoxProj1.Location = new System.Drawing.Point(227, 29);
            this.textBoxProj1.Name = "textBoxProj1";
            this.textBoxProj1.Size = new System.Drawing.Size(82, 20);
            this.textBoxProj1.TabIndex = 6;
            this.textBoxProj1.KeyDown += new System.Windows.Forms.KeyEventHandler(this.textBoxProj1_KeyDown);
            // 
            // textBoxProj2
            // 
            this.textBoxProj2.Location = new System.Drawing.Point(227, 66);
            this.textBoxProj2.Name = "textBoxProj2";
            this.textBoxProj2.Size = new System.Drawing.Size(82, 20);
            this.textBoxProj2.TabIndex = 17;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.LightSteelBlue;
            this.panel2.Controls.Add(this.label4);
            this.panel2.Controls.Add(this.textBoxProj2);
            this.panel2.Controls.Add(this.textBoxClient1);
            this.panel2.Controls.Add(this.textBoxProj1);
            this.panel2.Controls.Add(this.textBoxClient2);
            this.panel2.Controls.Add(this.textBoxContr2);
            this.panel2.Controls.Add(this.label5);
            this.panel2.Controls.Add(this.textBoxContr1);
            this.panel2.Controls.Add(this.label6);
            this.panel2.Location = new System.Drawing.Point(19, 167);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(333, 99);
            this.panel2.TabIndex = 41;
            // 
            // labelResult
            // 
            this.labelResult.AutoSize = true;
            this.labelResult.Location = new System.Drawing.Point(355, 451);
            this.labelResult.Name = "labelResult";
            this.labelResult.Size = new System.Drawing.Size(0, 13);
            this.labelResult.TabIndex = 42;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(338, 464);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(41, 13);
            this.label19.TabIndex = 43;
            this.label19.Text = "label19";
            this.label19.Click += new System.EventHandler(this.label19_Click);
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.BackColor = System.Drawing.Color.Red;
            this.label20.Location = new System.Drawing.Point(243, 127);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(202, 13);
            this.label20.TabIndex = 44;
            this.label20.Text = "Please enter a number between 1 and 52";
            this.label20.Visible = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Lavender;
            this.ClientSize = new System.Drawing.Size(846, 606);
            this.Controls.Add(this.label20);
            this.Controls.Add(this.label19);
            this.Controls.Add(this.labelResult);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.textboxReport);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.textBoxSup);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.textBoxEmp);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.checkBox7);
            this.Controls.Add(this.checkBox6);
            this.Controls.Add(this.checkBox5);
            this.Controls.Add(this.checkBox4);
            this.Controls.Add(this.checkBox3);
            this.Controls.Add(this.checkBox2);
            this.Controls.Add(this.checkBox1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox textBoxEmp;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBoxSup;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox textboxReport;
        private System.Windows.Forms.TextBox textBoxClient1;
        private System.Windows.Forms.TextBox textBoxContr1;
        private System.Windows.Forms.TextBox textBoxClient2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.CheckBox checkBox2;
        private System.Windows.Forms.CheckBox checkBox3;
        private System.Windows.Forms.CheckBox checkBox4;
        private System.Windows.Forms.CheckBox checkBox5;
        private System.Windows.Forms.CheckBox checkBox6;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TextBox textBoxSun;
        private System.Windows.Forms.TextBox textBoxFrid;
        private System.Windows.Forms.TextBox textBoxSat;
        private System.Windows.Forms.TextBox textBoxThur;
        private System.Windows.Forms.TextBox textBoxWed;
        private System.Windows.Forms.TextBox textBoxTues;
        private System.Windows.Forms.TextBox textBoxMon;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.CheckBox checkBox7;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TextBox textBoxTot1;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TextBox TextboxTot3;
        private System.Windows.Forms.TextBox textBoxFrid2;
        private System.Windows.Forms.TextBox textBoxSun2;
        private System.Windows.Forms.TextBox textBoxTot2;
        private System.Windows.Forms.TextBox MonTot;
        private System.Windows.Forms.TextBox FriTot;
        private System.Windows.Forms.TextBox SatTot;
        private System.Windows.Forms.TextBox SunTot;
        private System.Windows.Forms.TextBox TuesTot;
        private System.Windows.Forms.TextBox WedTot;
        private System.Windows.Forms.TextBox ThursTot;
        private System.Windows.Forms.TextBox textBoxThu2;
        private System.Windows.Forms.TextBox textBoxSat2;
        private System.Windows.Forms.TextBox textBoxWed2;
        private System.Windows.Forms.TextBox textBoxTue2;
        private System.Windows.Forms.TextBox textBoxMon2;
        private System.Windows.Forms.TextBox textBoxContr2;
        private System.Windows.Forms.TextBox textBoxProj1;
        private System.Windows.Forms.TextBox textBoxProj2;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label labelResult;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
    }
}

